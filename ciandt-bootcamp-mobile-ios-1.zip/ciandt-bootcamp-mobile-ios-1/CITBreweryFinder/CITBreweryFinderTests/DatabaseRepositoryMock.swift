//
//  DatabaseRepositoryMock.swift
//  CITBreweryFinderTests
//
//  Created by Filipe Nunes on 14/06/22.
//

@testable import CITBreweryFinder

class DatabaseRepositoryMock: DataBaseRepositoryProtocol {
    var favBrew: Favorite = Favorite()
    var error: BreweryError? = nil
    var forceError: Bool = false
    var returnError: Bool = false
    var deletedId: String?
    var isFavoriteId: String? = nil
    var favoriteBrewery: FavoriteBreweryModel?
    
    func saveFavorite(breweryFavorite: FavoriteBreweryModel) {
        favoriteBrewery = breweryFavorite
    }
    
    func fetchFavorites() -> [Favorite] {
        if forceError {
            returnError = true
            return [favBrew, favBrew, favBrew]
        } else {
            returnError = false
            return []
        }
    }
    
    func isFavorite(breweryId: String) -> Bool {
        isFavoriteId = breweryId
        return true
    }
    
    func deleteFavorite(breweryId: String) -> Bool {
        deletedId = breweryId
        return true
    }

}

