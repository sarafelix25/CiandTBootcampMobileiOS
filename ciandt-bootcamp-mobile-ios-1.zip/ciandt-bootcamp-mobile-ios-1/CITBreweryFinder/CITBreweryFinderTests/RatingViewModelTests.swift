//
//  RatingViewModelTests.swift
//  CITBreweryFinderTests
//
//  Created by Evele Kelle Lemos Silva on 14/06/22.
//

import Foundation
import XCTest
@testable import CITBreweryFinder

class RatingViewModelTests: XCTestCase {
    
    private var viewModel: RatingViewModel!
    private var repository = NetworkRepositoryMock()
    private var delegate: RatingViewModelDelegateMock!
    
    override func setUp() {
        delegate = RatingViewModelDelegateMock()
        viewModel = RatingViewModel(name: "", id: "", networkRepository: repository, delegate: delegate)
    }
    
    func testEvaluateBrewerySuccess(){
        repository.errorBreweryEvaluation = .success
        viewModel.evaluateBrewery(email: "test@email.com", breweryID: "0", evaluation: "5")
        XCTAssertEqual(viewModel.state.value, .success)
        XCTAssertTrue(delegate.passed)
    }
    
    func testEvaluateBreweryErrorEmail(){
        viewModel.evaluateBrewery(email: "test@_.com", breweryID: "0", evaluation: "5")
        XCTAssertEqual(viewModel.state.value, .start)
        XCTAssertFalse(viewModel.showEmailError.value)
    }
    
    func testEvaluateBreweryErrorGrade(){
        viewModel.evaluateBrewery(email: "test@email.com", breweryID: "0", evaluation: "0")
        XCTAssertEqual(viewModel.state.value, .start)
        XCTAssertFalse(viewModel.showGradeError.value)
    }
    
    func testEvaluateBreweryServerError() {
        repository.errorBreweryEvaluation = .serverError
        viewModel.evaluateBrewery(email: "test@email.com", breweryID: "0", evaluation: "5")
        XCTAssertEqual(viewModel.state.value, .serverError)
    }
    
    func testEvaluateBreweryAlreadyEvaluated() {
        repository.errorBreweryEvaluation = .alreadyEvaluated
        viewModel.evaluateBrewery(email: "test@email.com", breweryID: "0", evaluation: "5")
        XCTAssertEqual(viewModel.state.value, .alreadyEvaluated)
    }
    
    func testIsValidEmailSuccess() {
        let result = viewModel.isValidEmail("test@email.com")
        XCTAssertTrue(result)
    }
    
    func testIsValidEmailError() {
        let result = viewModel.isValidEmail("test@_.com")
        XCTAssertFalse(result)
    }
    
    func testIsValidGradeSuccess() {
        let result = viewModel.isValidGrade(5)
        XCTAssertTrue(result)
    }
    
    func testIsValidGradeError() {
        let result = viewModel.isValidGrade(0)
        XCTAssertFalse(result)
    }
    
}


