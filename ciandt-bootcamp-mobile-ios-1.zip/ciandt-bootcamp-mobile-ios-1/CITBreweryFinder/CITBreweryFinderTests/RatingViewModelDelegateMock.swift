//
//  RatingViewModelDelegateMock.swift
//  CITBreweryFinderTests
//
//  Created by Evele Kelle Lemos Silva on 15/06/22.
//

import Foundation
@testable import CITBreweryFinder

class RatingViewModelDelegateMock: RatingViewModelDelegate {
    var passed: Bool = false
    
    func didEvaluateBreweryWithSuccess() {
        passed = true
    }
}
