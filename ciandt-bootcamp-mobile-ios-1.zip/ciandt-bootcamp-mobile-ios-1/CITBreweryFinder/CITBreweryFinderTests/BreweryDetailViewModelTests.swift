//
//  BreweryDetailViewModelTests.swift
//  CITBreweryFinderTests
//
//  Created by Filipe Nunes on 14/06/22.
//

import Foundation
import XCTest
@testable import CITBreweryFinder

class BreweryDetailViewModelTests: XCTestCase {
    private var viewModel: BreweryDetailViewModel!
    private var networkRepository = NetworkRepositoryMock()
    private var databaseRepository = DatabaseRepositoryMock()
    private var isFavorite = true
    
    override func setUp() {
        super.setUp()
        viewModel = BreweryDetailViewModel(networkRepository: networkRepository, databaseRepository: databaseRepository, breweryID: "breweryMock")
    }
    
    override func tearDown(){
        viewModel = nil
        super.tearDown()
    }
    
    func testGetBreweryByIDSuccess() {
        viewModel.getBreweryByID()
        XCTAssertEqual(viewModel.breweryName.value, "breweryMock-brewery")
        XCTAssertEqual(viewModel.id, "breweryMock")
        XCTAssertEqual(viewModel.avgReviews.value, "0.5")
        XCTAssertEqual(viewModel.address.value, "alameda dos anjos")
        XCTAssertEqual(viewModel.avgReviews.value, 0.5.description)
        XCTAssertEqual(viewModel.starRating.value, 0.5)
        XCTAssertEqual(viewModel.amountOfReviews.value, 15)
        XCTAssertEqual(viewModel.type.value, "bar")
        XCTAssertEqual(viewModel.website.value, "www.google.com")
        XCTAssertEqual(viewModel.address.value, "alameda dos anjos")
        XCTAssertNotNil(viewModel.coordinates.value)
    }
    
    func testGetBreweryByIDWithFailure() {
        networkRepository.breweryByIDerror = .notFound
        viewModel.getBreweryByID()
        XCTAssertEqual(viewModel.state.value, .notFound)
    }
    
    func testGetNumberOfReviewsSuccess() {
        viewModel.getBreweryByID()
        XCTAssertEqual(viewModel.getNumberOfReviews(), "15 avaliações")
    }
    
    func testGetNumberOfReviewsWithFailure() {
        networkRepository.breweryByIDerror = .notFound
        viewModel.getBreweryByID()
        XCTAssertEqual(viewModel.getNumberOfReviews(), "0 avaliações")
    }
    
    //    Functions that use the databaseRepository
    func testFavoriteSuccess() {
        viewModel.type.value = "bar"
        viewModel.starRating.value = 5.0
        viewModel.breweryName.value = "paçoca-bar"
        viewModel.favorite()
        
        XCTAssertNotNil(databaseRepository.favoriteBrewery)
        XCTAssertEqual(databaseRepository.favoriteBrewery?.breweryId, "breweryMock")
        XCTAssertEqual(databaseRepository.favoriteBrewery?.average, 5.0)
        XCTAssertEqual(databaseRepository.favoriteBrewery?.breweryName.description, "paçoca-bar")
        XCTAssertEqual(databaseRepository.favoriteBrewery?.breweryType, "bar")
    }
    
    func testIsBreweryFavoriteSuccess() {
        viewModel.isBreweryFavorite()
        XCTAssertEqual(databaseRepository.isFavoriteId, "breweryMock")
    }
    
    func testDeleteFavoriteSuccess() {
        viewModel.idToDelete = "mock"
        viewModel.deleteFavorite()
        XCTAssertEqual("mock", databaseRepository.deletedId)
        XCTAssertNil(viewModel.idToDelete)
        XCTAssertEqual(viewModel.state.value, .start)
    }
    
    func testDeleteFavoriteWithFailure() {
        let previousState = viewModel.state.value
        viewModel.deleteFavorite()
        XCTAssertNil(databaseRepository.deletedId)
        XCTAssertEqual(viewModel.state.value, previousState)
    }
    
}
