//
//  SearchResultsViewModelTests.swift
//  CITBreweryFinderTests
//
//  Created by Filipe Nunes on 15/06/22.
//


import Foundation
import XCTest
@testable import CITBreweryFinder

class SearchResultsViewModelTests: XCTestCase {
    private var viewModel: SearchResultsViewModel!
    private var networkRepository = NetworkRepositoryMock()
    private var databaseRepository = DatabaseRepositoryMock()
    private var isFavorite = true
    
    override func setUp() {
        super.setUp()
        viewModel = SearchResultsViewModel(with: Brewery(id: "breweryMock",
                                                   name: "breweryMock",
                                                   breweryType: "bar",
                                                   city: "la",
                                                   postalCode: "90210",
                                                   country: "usa",
                                                   average: 3.4,
                                                   sizeEvaluations: 35),
                                           databaseRepository: databaseRepository)
    }
    
    override func tearDown(){
        viewModel = nil
        super.tearDown()
    }

    func testFavoriteSuccess() {
        viewModel.favoriteBrewery()
        
        XCTAssertNotNil(databaseRepository.favoriteBrewery)
        XCTAssertEqual(databaseRepository.favoriteBrewery?.breweryId.description, "breweryMock")
        XCTAssertEqual(databaseRepository.favoriteBrewery?.average, 3.4)
        XCTAssertEqual(databaseRepository.favoriteBrewery?.breweryName.description, "breweryMock")
        XCTAssertEqual(databaseRepository.favoriteBrewery?.breweryType, "bar")
    }
    
    func testIsBreweryFavoriteSuccess() {
        XCTAssertNil(databaseRepository.isFavoriteId)
        viewModel.isBreweryFavorite()
        XCTAssertEqual(databaseRepository.isFavoriteId, "breweryMock")
    }
    
    func testDeleteFavoriteSuccess() {
        XCTAssertNil(databaseRepository.deletedId)
        viewModel.deleteFavorite()
        XCTAssertEqual(databaseRepository.deletedId, "breweryMock")
    }
    
}

