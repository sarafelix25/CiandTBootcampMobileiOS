//
//  NetworkRepository.swift
//  CITBreweryFinderTests
//
//  Created by Filipe Nunes on 14/06/22.
//

@testable import CITBreweryFinder

class NetworkRepositoryMock: NetworkRepositoryProtocol {
    
    var brewery: Brewery? = nil
    var breweryList: [Brewery]? = nil
    
    var error: BreweryError? = nil
    var breweryByIDerror: BreweryDetailError? = nil
    var breweryByLocalerror: BreweryError? = nil
    var forceError: Bool = false
    
    var errorBreweryEvaluation: BreweryPostResult? = nil
    var breweryEmpty = Brewery(id: "",
                              name: "",
                              breweryType: "",
                              street: "",
                              address2: "",
                              address3: "",
                              city: "",
                              state: "",
                              postalCode: "",
                              country: "",
                              longitude: 0.0,
                              latitude: 0.0,
                              websiteUrl: "",
                              phone: "",
                              average: 0.0,
                              sizeEvaluations: 0,
                              photos: ["", ""])
    let brewery1 = Brewery(id: "breweryMock",
                           name: "breweryMock-brewery",
                           breweryType: "bar",
                           street: "alameda dos anjos",
                           address2: "38",
                           address3: "apto101",
                           city: "los angeles",
                           state: "california",
                           postalCode: "90218",
                           country: "usa",
                           longitude: 0.0,
                           latitude: 0.0,
                           websiteUrl: "www.google.com",
                           phone: "510908",
                           average: 0.5,
                           sizeEvaluations: 15,
                           photos: ["abc", "def"])
    
    func fetchBreweryByLocal(_ local: String, completion: @escaping ([Brewery], BreweryError?) -> ()) {
        if error == nil {
            completion([brewery1, brewery1], nil)
        } else {
            completion([], error)
        }
    }
    
    func fetchBreweryRatedByEmail(email: String, completion: @escaping ([Brewery], BreweryRatedError?) -> ()) {
        if forceError {
            completion([], .error)
        } else {
            completion([brewery1, brewery1, brewery1], nil)
        }
    }
    
    func fetchBreweryByID(id: String, completion: @escaping (Brewery, BreweryDetailError?) -> ()) {
        if breweryByIDerror != nil {
            completion(breweryEmpty, breweryByIDerror)
        } else {
            completion(brewery1, nil)
        }
    }
    
    func breweryEvaluation(email: String, breweryID: String, evaluation: String, completion: @escaping(BreweryPostResult?) -> ()) {
        if errorBreweryEvaluation == .success {
            completion(.success)
        } else if errorBreweryEvaluation == .serverError {
            completion(.serverError)
        } else {
            completion(.alreadyEvaluated)
        }
    }
    
    func fetchBreweryTopTen(completion: @escaping ([Brewery], BreweryError?) -> ()) {
        if error == nil {
            completion([brewery1, brewery1, brewery1], nil)
        } else {
            completion([], error)
        }
    }
}
