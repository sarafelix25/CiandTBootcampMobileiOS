//
//  HomeBreweryFinderTests.swift
//  CITBreweryFinderTests
//
//  Created by Sara Batista dos Santos Felix on 14/06/22.
//

import UIKit
import XCTest
@testable import CITBreweryFinder

class HomeBreweryFinderTests: XCTestCase {
    private var homeModel: HomeViewModel!
    private var networkRepository = NetworkRepositoryMock()
    private var databaseRepository = DatabaseRepositoryMock()
    var callLoading: Bool = false
    
    override func setUp() async throws {
        networkRepository = NetworkRepositoryMock()
        databaseRepository = DatabaseRepositoryMock()
        homeModel = HomeViewModel(breweryRepository: networkRepository, databaseRepository: databaseRepository)
        callLoading = false
    }
    
    func testGetBreweryByLocalSuccess() {
        let successExp = XCTestExpectation(description: "Success")
        
        homeModel.state.bindWithoutFire { state in
            switch state {
            case .loading:
                self.callLoading = true
                break
            case .success(let breweryList):
                XCTAssertEqual(breweryList.count, 2)
                XCTAssertTrue(self.callLoading)
                successExp.fulfill()
                break
            default:
                XCTFail("state diferente de sucesso: \(state)")
            }
        }
        
        homeModel.getBreweryByLocal("Florida")
        wait(for: [successExp], timeout: 5)
    }
    
    func testGetBreweryByLocalErrorNotFound() {
        let errorExp = XCTestExpectation(description: "Error not found")
        networkRepository.error = .notFound
        
        homeModel.state.bindWithoutFire { state in
            switch state {
            case .loading:
                self.callLoading = true
                break
            case .notFound:
                XCTAssertTrue(self.callLoading)
                errorExp.fulfill()
                break
            default:
                XCTFail("state diferente de not found: \(state)")
            }
        }
        
        homeModel.getBreweryByLocal("Florida")
        wait(for: [errorExp], timeout: 5)
    }
    
    func testGetBreweryByLocalErrorNoEntry() {
        let errorExp = XCTestExpectation(description: "Error no entry")
        networkRepository.error = .noEntry
        
        homeModel.state.bindWithoutFire { state in
            switch state {
            case .loading:
                self.callLoading = true
                break
            case .noEntry:
                XCTAssertTrue(self.callLoading)
                errorExp.fulfill()
                break
            default:
                XCTFail("state diferente de no entry: \(state)")
            }
        }
        
        homeModel.getBreweryByLocal("Florida")
        wait(for: [errorExp], timeout: 5)
    }
    
    
    func testGetBreweryTopTenSuccess() {
        let successExp = XCTestExpectation(description: "Success")
        
        homeModel.state.bindWithoutFire { state in
            switch state {
            case .loading:
                self.callLoading = true
                break
            case .showTopTen(let breweryList):
                XCTAssertEqual(breweryList.count, 3)
                XCTAssertTrue(self.callLoading)
                successExp.fulfill()
                break
            default:
                XCTFail("state diferente de show top ten: \(state)")
            }
        }
        
        homeModel.getBreweryTopTen()
        wait(for: [successExp], timeout: 5)
    }
    
    func testGetBreweryTopTenError() {
        let errorExp = XCTestExpectation(description: "Error")
        networkRepository.error = .notFound
        
        homeModel.state.bindWithoutFire { state in
            switch state {
            case .loading:
                self.callLoading = true
                break
            case .notFound:
                XCTAssertTrue(self.callLoading)
                errorExp.fulfill()
                break
            default:
                XCTFail("state diferente de not found: \(state)")
            }
        }
        
        homeModel.getBreweryTopTen()
        wait(for: [errorExp], timeout: 5)
    }
    
    func testDeleteFavoriteSuccess() {
        homeModel.idToDelete = "mock"
        homeModel.deleteFavorite()
        XCTAssertEqual("mock", databaseRepository.deletedId)
        XCTAssertNil(homeModel.idToDelete)
    }
    
    func testDeleteFavoriteWithFailure() {
        let previousState = homeModel.state.value
        homeModel.deleteFavorite()
        XCTAssertNil(databaseRepository.deletedId)
    }
}
