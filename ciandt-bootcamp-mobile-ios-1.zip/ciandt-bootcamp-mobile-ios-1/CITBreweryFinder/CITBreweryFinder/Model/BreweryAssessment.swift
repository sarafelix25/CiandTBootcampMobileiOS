//
//  BreweryAssessment.swift
//  CI&T Brewery Finder
//
//  Created by Filipe Nunes on 04/06/22.
//

import Foundation

struct BreweryAssessment: Codable {
    var email: String
    var breweryId: String
    var evaluationGrade: Double
    
    enum CodingKeys: String, CodingKey {
        case email
        case breweryId = "brewery_id"
        case evaluationGrade = "evaluation_grade"
    }
}

public enum BreweryPostResult: Codable, Error {
    case success
    case alreadyEvaluated
    case serverError
}
