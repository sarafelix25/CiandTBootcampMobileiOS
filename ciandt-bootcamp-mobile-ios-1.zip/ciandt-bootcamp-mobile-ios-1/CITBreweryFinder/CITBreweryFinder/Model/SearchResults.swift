//
//  SearchResults.swift
//  CI&T Brewery Finder
//
//  Created by Swelen Poliana Cesario Ebert on 18/05/22.
//

import Foundation

struct SearchResults {
   // var bImage: UIImage
    var bName: String
   // var starIcon: [UIImage]
    var ratio: Int
    var category: String
}
