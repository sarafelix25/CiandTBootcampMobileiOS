//
//  MyFavoriteBrewery.swift
//  CI&T Brewery Finder
//
//  Created by Sara Batista dos Santos Felix on 09/06/22.
//

import Foundation

public struct FavoriteBreweryModel {
    let breweryId: String
    let breweryType: String
    let average: Float
    let breweryName: String
    
}
