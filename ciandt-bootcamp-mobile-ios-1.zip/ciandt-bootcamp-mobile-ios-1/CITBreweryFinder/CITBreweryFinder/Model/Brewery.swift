//
//  Brewery.swift
//  CI&T Brewery Finder
//
//  Created by Evele Kelle Lemos Silva on 16/05/22.
//

import Foundation

public struct Brewery: Codable, Equatable {
    
    var id: String
    var name: String
    var breweryType: String
    var street: String?
    var address2: String?
    var address3: String?
    var city: String
    var state: String?
    var postalCode: String
    var country: String
    var longitude: Float?
    var latitude: Float?
    var websiteUrl: String?
    var phone: String?
    var average: Float
    var sizeEvaluations: Int
    var photos: [String]?
    
    enum CodingKeys: String, CodingKey {
        case id
        case name
        case breweryType = "brewery_type"
        case street
        case address2
        case address3
        case city
        case state
        case postalCode = "postal_code"
        case country
        case longitude
        case latitude
        case websiteUrl = "website_url"
        case phone
        case average
        case sizeEvaluations = "size_evaluations"
        case photos
    }
    
}

extension Brewery {
    init(with favorite: Favorite){
        id = favorite.breweryId
        name = favorite.breweryName
        breweryType = favorite.breweryType
        city = ""
        postalCode = ""
        country = ""
        average = favorite.average
        sizeEvaluations = 0
    }
    
}
