//
//  BreweryError.swift
//  CI&T Brewery Finder
//
//  Created by Evele Kelle Lemos Silva on 17/05/22.
//

import Foundation

public enum BreweryError: Error {
    case notFound
    case noEntry
}

public enum BreweryDetailError: Error {
    case notFound
}

public enum BreweryRatedError: Error {
    case error
}
