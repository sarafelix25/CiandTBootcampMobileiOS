//
//  Favorite+CoreDataClass.swift
//  CI&T Brewery Finder
//
//  Created by Sara Batista dos Santos Felix on 08/06/22.
//

import Foundation
import CoreData

@objc(Favorite)
public class Favorite: NSManagedObject {
    
}
