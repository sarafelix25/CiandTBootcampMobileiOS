//
//  Favorite+CoreDataProperties.swift
//  CI&T Brewery Finder
//
//  Created by Sara Batista dos Santos Felix on 08/06/22.
//

import Foundation
import CoreData

extension Favorite {
    
    @nonobjc public class func fetchRequest() -> NSFetchRequest<Favorite> {
        return NSFetchRequest<Favorite>(entityName: "Favorite")
    }
    
    @NSManaged public var breweryName: String
    @NSManaged public var breweryId: String
    @NSManaged public var average: Float
    @NSManaged public var breweryType: String
}
