//
//  SearchResultsViewModel.swift
//  CI&T Brewery Finder
//
//  Created by Filipe Nunes on 08/06/22.
//

import UIKit

class SearchResultsViewModel{
    
    let name: Observable<String>
    let type: Observable<String>
    let rate: Observable<Float>
    let firstLetter: Observable<String>
    let id: String
    let photos: Observable<[String]?>
    let city: Observable<String>
    let website: String?
    
    private let databaseRepository: DataBaseRepositoryProtocol
    
    init(with brewery: Brewery, databaseRepository: DataBaseRepositoryProtocol = DataBaseRepository()) {
        self.databaseRepository = databaseRepository
        self.name = Observable(brewery.name)
        self.type = Observable(brewery.breweryType)
        self.rate = Observable(brewery.average)
        self.firstLetter = Observable(String(brewery.name.first ?? " "))
        self.id = brewery.id
        self.photos = Observable(brewery.photos)
        self.city = Observable(brewery.city)
        self.website = brewery.websiteUrl
    }
    
    func isBreweryFavorite() -> Bool {
        return databaseRepository.isFavorite(breweryId: self.id)
    }
    
    func favoriteBrewery() {
        let favoriteBrewery = FavoriteBreweryModel(breweryId: id,
                                                   breweryType: type.value,
                                                   average: rate.value,
                                                   breweryName: name.value)
        databaseRepository.saveFavorite(breweryFavorite: favoriteBrewery)
    }
    
    func deleteFavorite() -> Bool {
        databaseRepository.deleteFavorite(breweryId: self.id)
    }

    
}
