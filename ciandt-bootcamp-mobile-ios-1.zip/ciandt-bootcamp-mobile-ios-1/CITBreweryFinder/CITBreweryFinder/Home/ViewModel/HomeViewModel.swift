//
//  HomeViewModel.swift
//  CI&T Brewery Finder
//
//  Created by Evele Kelle Lemos Silva on 16/05/22.
//

import Foundation

public class HomeViewModel {
    
    private let networkRepository: NetworkRepositoryProtocol
    private let databaseRepository: DataBaseRepositoryProtocol
    
    let state = Observable<HomeViewState>(.initial)
    
    var idToDelete: String? = nil
    
    init(breweryRepository: NetworkRepositoryProtocol = NetworkRepository(),
         databaseRepository: DataBaseRepositoryProtocol = DataBaseRepository()) {
        self.networkRepository = breweryRepository
        self.databaseRepository = databaseRepository
    }
    
    func getBreweryByLocal(_ local: String) {
        if local == "" {
            self.state.value = .noEntry
        } else {
            self.state.value = .loading
            networkRepository.fetchBreweryByLocal(local) { result, error in
                if let error = error {
                    switch error {
                    case .noEntry:
                        self.state.value = .noEntry
                    case .notFound:
                        self.state.value = .notFound
                    }
                } else {
                    let filterResult = result.sorted { $0.average > $1.average }
                    var searchResultsViewModels = [SearchResultsViewModel]()
                    for result in filterResult {
                        searchResultsViewModels.append(SearchResultsViewModel(with: result))
                    }
                    self.state.value = .success(breweryList: searchResultsViewModels)
                }
            }
        }
    }
    
    func getBreweryTopTen() {
        self.state.value = .loading
        networkRepository.fetchBreweryTopTen() { result, error in
            if let error = error {
                switch error {
                case .noEntry:
                    self.state.value = .noEntry
                case .notFound:
                    self.state.value = .notFound
                }
            } else {
                let filterResult = result.sorted { $0.average > $1.average }
                var searchResultsViewModels = [SearchResultsViewModel]()
                for result in filterResult {
                    searchResultsViewModels.append(SearchResultsViewModel(with: result))
                }
                self.state.value = .showTopTen(breweryList: searchResultsViewModels)
            }
        }
    }

    func deleteFavorite() {
        guard let id = idToDelete
        else {
            return
        }
        _ = databaseRepository.deleteFavorite(breweryId: id)
        idToDelete = nil
    }

}

enum HomeViewState {
    case initial
    case showTopTen(breweryList: [SearchResultsViewModel])
    case loading
    case success(breweryList: [SearchResultsViewModel])
    case notFound
    case noEntry
}
