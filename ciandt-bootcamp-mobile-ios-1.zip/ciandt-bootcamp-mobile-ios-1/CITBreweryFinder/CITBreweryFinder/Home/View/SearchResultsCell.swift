//
//  SearchResultsCell.swift
//  CI&T Brewery Finder
//
//  Created by Swelen Poliana Cesario Ebert on 15/05/22.
//

import UIKit
import SwiftyStarRatingView

protocol SearchResultCellDelegate: AnyObject {
    func shareAction(_ url: String?)
    func deleteFavorite(id: String)
}

class SearchResultsCell: UITableViewCell {
    
    
    @IBOutlet weak var cellBackground: UIView?
    @IBOutlet weak var breweryName: UILabel?
    @IBOutlet weak var breweryType: UILabel?
    @IBOutlet weak var rate: UILabel?
    @IBOutlet weak var firstLetter: UILabel?
    @IBOutlet weak var favoriteButton: UIButton!
    @IBOutlet weak var shareButton: UIButton!
    @IBOutlet weak var ratingView: SwiftyStarRatingView? {
        didSet {
            ratingView?.isEnabled = false
        }
    }
    
    
    weak var delegate: SearchResultCellDelegate?
    
    @IBAction func shareButtonAction(_ sender: Any) {
            self.delegate?.shareAction(viewModel?.website)
    }
    
    var viewModel: SearchResultsViewModel?
    var isFavorite: Bool = false
     
    
    func setupWith (_ viewModel: SearchResultsViewModel, delegate: SearchResultCellDelegate? = nil) {
        cellBackground?.setShadowWithCornerRadius(cornerRadius: 30, shadowColor: .gray, shadowOffset: CGSize(width: 0, height: 1), shadowOpacity: 0.4, shadowRadius: 2)
                
        self.viewModel = viewModel
        self.bindings()
        self.setFavoriteIcon()
        self.setShareButton()
        self.delegate = delegate
 
    }
    
    func bindings() {
        viewModel?.name.bind { [weak self] name in
            self?.breweryName?.text = name
        }
        
        viewModel?.type.bind { [weak self] type in
            self?.breweryType?.text = type
        }
        
        viewModel?.rate.bind { [weak self] rate in
            self?.rate?.text = String(rate)
            self?.ratingView?.value = CGFloat(rate)
        }
        
        viewModel?.firstLetter.bind { [weak self] firstLetter in
            self?.firstLetter?.text = firstLetter
        }
    }
    
    func setShareButton() {
        if self.viewModel?.website == nil {
            self.shareButton.isHidden = true
        }
        else {
            self.shareButton.isHidden = false
        }
    }
    
    func setFavoriteIcon() {
        isFavorite = viewModel?.isBreweryFavorite() ?? false
        
        if isFavorite {
            favoriteButton.setImage(UIImage(systemName: "heart.fill"), for: UIControl.State.normal)
            favoriteButton.tintColor = UIColor(.red)
        } else {
            favoriteButton.setImage(UIImage(systemName: "heart"), for: UIControl.State.normal)
            favoriteButton.tintColor = UIColor(.black)
        }
    }
    
    @IBAction func clickedFavoriteButton(_ sender: Any) {
        
        if isFavorite {
            self.delegate?.deleteFavorite(id: viewModel?.id ?? "")
        }
        else {
            viewModel?.favoriteBrewery()
        }
        setFavoriteIcon()
    }
    
}
