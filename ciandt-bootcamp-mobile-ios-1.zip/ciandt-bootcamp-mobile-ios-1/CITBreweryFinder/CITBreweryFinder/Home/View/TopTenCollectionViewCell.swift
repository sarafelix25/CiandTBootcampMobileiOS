//
//  TopTenCollectionViewCell.swift
//  CI&T Brewery Finder
//
//  Created by André Levi Oliveira Silva on 09/06/22.
//

import UIKit
import Kingfisher

class TopTenCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var breweryImageView: UIImageView!
    @IBOutlet weak var breweryName: UILabel!
    @IBOutlet weak var breweryNote: UILabel!
    @IBOutlet weak var breweryType: UILabel!
    @IBOutlet weak var breweryCity: UILabel!
    
    
    var viewModel: SearchResultsViewModel?
    
    func setup(_ viewModel: SearchResultsViewModel) {
            
        self.viewModel = viewModel
        
        viewModel.photos.bind { [weak self] photos in
            let url = URL(string: photos?.first ?? "")
            self?.breweryImageView.kf.setImage(with: url)
        }
        
        viewModel.name.bind { [weak self] name in
            self?.breweryName?.text = name
        }
        
        viewModel.type.bind { [weak self] type in
            self?.breweryType?.text = type
        }

        viewModel.city.bind { [weak self] city in
            self?.breweryCity?.text = city
        }

        viewModel.rate.bind { [weak self] average in
            self?.breweryNote?.text = String(average)
        }
        
        self.setShadowWithCornerRadius(cornerRadius: 16, shadowColor: .gray, shadowRadius: 0)
    }
    
    
}
