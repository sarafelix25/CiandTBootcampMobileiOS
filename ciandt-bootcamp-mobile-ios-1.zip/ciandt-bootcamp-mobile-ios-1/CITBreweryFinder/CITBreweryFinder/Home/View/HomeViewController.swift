//
//  ViewController.swift
//  CI&T Brewery Finder
//
//  Created by Sara Batista dos Santos Felix on 13/05/22.
//

import UIKit
import DGCarouselFlowLayout
import CoreData

class HomeViewController: UIViewController {
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var subtitle: UILabel!
    
    @IBOutlet weak var searchBar: UISearchBar!
    
    @IBOutlet weak var titleTableView: UILabel!
    @IBOutlet weak var subtitleTableView: UILabel!
    @IBOutlet weak var homeTableView: UITableView!
    
    @IBOutlet weak var breweryNotFoundView: UIView!
    @IBOutlet weak var noEntryView: UIView!
    
    @IBOutlet weak var loadingView: UIView!
    @IBOutlet weak var loadingActIndicator: UIActivityIndicatorView!
    @IBOutlet weak var numberOfResults: UILabel!
    
    @IBOutlet weak var collectionVew: UICollectionView!
    @IBOutlet weak var topTenTitleLabel: UILabel!
    
    @IBOutlet weak var loadingImageView: UIImageView!
    
    var loading1: UIImage!
    var loading2: UIImage!
    var loading3: UIImage!
    var loading4: UIImage!
    
    public var breweryList: [SearchResultsViewModel] = []
    public var breweries: [NSManagedObject] = []
    let viewModel = HomeViewModel()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initialSetup()
        setupActivityIndicator()
        
        collectionVew.dataSource = self
        collectionVew.delegate = self
        let layout = DGCarouselFlowLayout()
        layout.scrollDirection = .horizontal
        layout.itemSize = .init(width: 150, height: 250)
        layout.sideItemScale = 0.9
        layout.sideItemAlpha = 0.7
        layout.spacingMode = .fixed(spacing: 12)
        collectionVew.collectionViewLayout = layout
        
        viewModel.state.bind { [weak self] state in
            switch state {
            case .initial:
                self?.collectionVew.reloadData()
                self?.showTopTen()
            case .showTopTen(let breweryList):
                self?.showLoading(show: false)
                self?.topTenTitleLabel.isHidden = false
                self?.collectionVew.isHidden = false
                self?.breweryList = breweryList
                self?.collectionVew.reloadData()
            case .success(let breweryList):
                self?.showLoading(show: false)
                self?.breweryList = breweryList
                self?.activateTableView()
                self?.homeTableView.reloadData()
            case .loading:
                self?.showLoading(show: true)
            case .notFound:
                self?.showLoading(show: false)
                self?.activateErrorNotFoundView()
            case .noEntry:
                self?.showLoading(show: false)
                self?.activateErrorNoEntry()
            }
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if !homeTableView.isHidden {
            homeTableView.reloadData()
        }
    }
    
    //    MARK: Setup UI
    func initialSetup() {
        homeTableView.dataSource = self
        homeTableView.delegate = self
        searchBar.delegate = self
        setupNavigationBar()
        collectionVew.isHidden = false
        homeTableView.register(UINib(nibName: "SearchResultsCell", bundle: nil), forCellReuseIdentifier: "SearchResultsCell")
        homeTableView.isHidden = true
        breweryNotFoundView.isHidden = true
        noEntryView.isHidden = true
        titleTableView.isHidden = true
        subtitleTableView.isHidden = true
        loadingView.isHidden = true
        topTenTitleLabel.isHidden = false
    }
    
    func setupActivityIndicator() {
        loading1 = UIImage(named: "breweryActInd1.png")
        loading2 = UIImage(named: "breweryActInd2.png")
        loading3 = UIImage(named: "breweryActInd3.png")
        loading4 = UIImage(named: "breweryActInd4.png")
        
        var images: [UIImage]!
        var animatedImage: UIImage!
        images = [loading1, loading2, loading3, loading4]
        animatedImage = UIImage.animatedImage(with: images, duration: 0.5)
        loadingImageView.image = animatedImage
    }
    
    func activateTableView() {
        self.numberOfResults.text = breweryList.count == 1 ? NSLocalizedString("Home.numberOfBrewerySearchOneResult", comment: "") :
        String(format: NSLocalizedString("Home.numberOfBrewerySearchResults", comment: ""), breweryList.count)
        homeTableView.isHidden = false
        titleTableView.isHidden = false
        subtitleTableView.isHidden = false
        breweryNotFoundView.isHidden = true
        noEntryView.isHidden = true
        loadingView.isHidden = true
        collectionVew.isHidden = true
        topTenTitleLabel.isHidden = true
    }
    
    func activateErrorNotFoundView() {
        subtitleTableView.isHidden = true
        titleTableView.isHidden = true
        breweryNotFoundView.isHidden = false
        noEntryView.isHidden = true
        homeTableView.isHidden = true
        loadingView.isHidden = true
        collectionVew.isHidden = true
        topTenTitleLabel.isHidden = true
    }
    
    func activateErrorNoEntry() {
        subtitleTableView.isHidden = true
        titleTableView.isHidden = true
        noEntryView.isHidden = false
        breweryNotFoundView.isHidden = true
        homeTableView.isHidden = true
        loadingView.isHidden = true
        collectionVew.isHidden = true
        topTenTitleLabel.isHidden = true
    }
    
    func showTopTen() {
        viewModel.getBreweryTopTen()
    }
    
    func showLoading(show: Bool) {
        topTenTitleLabel.isHidden = true
        collectionVew.isHidden = true
        subtitleTableView.isHidden = true
        titleTableView.isHidden = true
        noEntryView.isHidden = true
        breweryNotFoundView.isHidden = true
        homeTableView.isHidden = true
        loadingView.isHidden = !show
        if show {
            loadingImageView.isHidden = false
        } else {
            loadingImageView.isHidden = true
        }
    }
    
    func setupNavigationBar() {
        navigationItem.title = NSLocalizedString("CI&T Brewery Finder", comment: "")
        navigationController?.navigationBar.prefersLargeTitles = true
        navigationItem.hidesSearchBarWhenScrolling = false
    }
    
    @IBAction func showFavorites(_ sender: Any) {
        let favoriteViewController = FavoriteBreweriesViewController()
        
        self.navigationController?.pushViewController(favoriteViewController, animated: true)
    }
    
    @IBAction func showRated(_ sender: Any) {
        let emailViewController = FillEmailViewController()
        
        self.navigationController?.pushViewController(emailViewController, animated: true)
    }
    
    @IBAction func showTopTen(_ sender: Any) {
        viewModel.state.value = .initial
    }
}

// MARK: Extensions
extension HomeViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return breweryList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "SearchResultsCell", for: indexPath) as? SearchResultsCell else {
            return UITableViewCell()
        }
        cell.selectionStyle = .none
        cell.setupWith(breweryList[indexPath.row],delegate: self)
        return cell
    }
    
}

extension HomeViewController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        tableView.deselectRow(at: indexPath, animated: true)
        
        let breweryDetailViewController = BreweryDetailViewController()
        let breweryDetailViewModel = BreweryDetailViewModel(breweryID: breweryList[indexPath.row].id, website: breweryList[indexPath.row].website ?? "")
        
        breweryDetailViewController.viewModel = breweryDetailViewModel
        self.navigationController?.pushViewController(breweryDetailViewController, animated: true)
    }
    
}

extension HomeViewController: UISearchBarDelegate {
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        viewModel.getBreweryByLocal(searchBar.text ?? "invalid")
        searchBar.endEditing(true)
    }
}

extension HomeViewController: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return breweryList.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "TopTenCollectionViewCell", for: indexPath) as! TopTenCollectionViewCell
        cell.setup(breweryList[indexPath.row])
        return cell
    }
    
}

extension HomeViewController: UICollectionViewDelegate {
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        collectionView.deselectItem(at: indexPath, animated: true)
        
        let breweryDetailViewController = BreweryDetailViewController()
        let breweryDetailViewModel = BreweryDetailViewModel(breweryID: breweryList[indexPath.row].id, website: breweryList[indexPath.row].website ?? "")
        
        breweryDetailViewController.viewModel = breweryDetailViewModel
        self.navigationController?.pushViewController(breweryDetailViewController, animated: true)
    }
    
}

extension HomeViewController: SearchResultCellDelegate {
    
    func deleteFavorite(id: String) {
        viewModel.idToDelete = id
        let removeFavViewController = RemoveFavoriteViewController()
        removeFavViewController.delegate = self
        removeFavViewController.modalPresentationStyle = .overCurrentContext
        present(removeFavViewController, animated: true, completion: nil)
    }
    
    func shareAction(_ url: String?) {
        let activityVC = UIActivityViewController(activityItems: [url as AnyObject], applicationActivities: nil)
        activityVC.popoverPresentationController?.sourceView = self.view
        self.present(activityVC, animated: true, completion: nil)
    }
}

extension HomeViewController: RemoveFavoriteDelegate {
    func confirmDeletion() {
        viewModel.deleteFavorite()
        homeTableView.reloadData()
        self.presentedViewController?.dismiss(animated: true)
    }
    
    func cancelDeletion() {
        self.presentedViewController?.dismiss(animated: true)
    }
}
