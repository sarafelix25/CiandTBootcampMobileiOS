//
//  Extensions.swift
//  CI&T Brewery Finder
//
//  Created by Filipe Nunes on 20/05/22.
//

import UIKit

extension UIView {
    func setShadowWithCornerRadius(cornerRadius: CGFloat, shadowColor: UIColor, shadowOffset: CGSize = .zero, shadowOpacity: Float = 1, shadowRadius: CGFloat) {
        
        layer.cornerRadius = cornerRadius
        layer.shadowColor  = shadowColor.cgColor
        layer.shadowOffset = shadowOffset
        layer.shadowOpacity = shadowOpacity
        layer.shadowRadius = shadowRadius
    }
}
