//
//  FavoriteBreweriesViewController.swift
//  CI&T Brewery Finder
//
//  Created by Filipe Nunes on 08/06/22.
//

import UIKit

class FavoriteBreweriesViewController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var numberOfResults: UILabel!
    @IBOutlet weak var noFavoriteView: UIView!
    @IBOutlet weak var loadingView: UIView!
    @IBOutlet weak var loadingActIndicator: UIActivityIndicatorView!
    
    @IBOutlet weak var loadingImageView: UIImageView!
    
    var loading1: UIImage!
    var loading2: UIImage!
    var loading3: UIImage!
    var loading4: UIImage!
    
    var breweryList: [SearchResultsViewModel] = []
    var viewModel = FavoriteBreweriesViewModel()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initialSetup()
        setupActivityIndicator()
        
        viewModel.state.bind { [weak self] state in
            switch state {
            case .start:
                self?.showLoading(show: true)
                self?.getResults()
            case .success(let breweryList):
                self?.showLoading(show: false)
                self?.breweryList = breweryList
                self?.showTableView()
                self?.tableView.reloadData()
            case .emptyFavorites:
                self?.showLoading(show: false)
                self?.showNoFavoriteBrewery()
            case .loading:
                self?.showLoading(show: true)
            }
        }
        
    }
    
    func initialSetup() {
        tableView.dataSource = self
        tableView.delegate = self
        tableView.register(UINib(nibName: "SearchResultsCell", bundle: nil), forCellReuseIdentifier: "SearchResultsCell")
        numberOfResults.isHidden = true
        
    }
    
    func setupActivityIndicator() {
        loading1 = UIImage(named: "breweryActInd1.png")
        loading2 = UIImage(named: "breweryActInd2.png")
        loading3 = UIImage(named: "breweryActInd3.png")
        loading4 = UIImage(named: "breweryActInd4.png")
        
        var images: [UIImage]!
        var animatedImage: UIImage!
        images = [loading1, loading2, loading3, loading4]
        animatedImage = UIImage.animatedImage(with: images, duration: 0.5)
        loadingImageView.image = animatedImage
    }
    
    func showLoading(show: Bool) {
        loadingView.isHidden = !show
        if show {
            loadingImageView.isHidden = false
        } else {
            loadingImageView.isHidden = true
        }
    }
    
    func showTableView() {
        numberOfResults.isHidden = false
        tableView.isHidden = false
        noFavoriteView.isHidden = true
        numberOfResults.text = breweryList.count == 1 ? NSLocalizedString("Favorite.numberOfBrewerySearchOneResult", comment: "") :
        String(format: NSLocalizedString("Favorite.numberOfBrewerySearchResults", comment: ""), breweryList.count)
    }
    
    func showNoFavoriteBrewery() {
        numberOfResults.isHidden = true
        tableView.isHidden = true
        noFavoriteView.isHidden = false
        
        let view = UINib(nibName: "NoFavoriteBrewery", bundle: .main).instantiate(withOwner: nil, options: nil).first as! UIView
        view.frame = self.noFavoriteView.bounds
        
        noFavoriteView.addSubview(view)
    }
    
    func showDeletionConfirmation() {
        tableView.isHidden = true
        noFavoriteView.isHidden = false
        
    }
    
    func getResults() {
        viewModel.getFavoriteBreweries()
    }
    
    
}



extension FavoriteBreweriesViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return breweryList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "SearchResultsCell", for: indexPath) as? SearchResultsCell else {
            return UITableViewCell()
        }
        cell.selectionStyle = .none
        cell.setupWith(breweryList[indexPath.row], delegate: self)
        return cell
    }
    
}

extension FavoriteBreweriesViewController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        tableView.deselectRow(at: indexPath, animated: true)
        let breweryDetailViewController = BreweryDetailViewController()
        let breweryDetailViewModel = BreweryDetailViewModel(breweryID: breweryList[indexPath.row].id, website: breweryList[indexPath.row].website ?? "")
        
        breweryDetailViewController.viewModel = breweryDetailViewModel
        self.navigationController?.pushViewController(breweryDetailViewController, animated: true)
    }
    
    // Set the spacing between sections
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 15
    }
}


extension FavoriteBreweriesViewController: SearchResultCellDelegate {
    func deleteFavorite(id: String) {
        viewModel.idToDelete = id
        let removeFavViewController = RemoveFavoriteViewController()
        removeFavViewController.delegate = self
        removeFavViewController.modalPresentationStyle = .overCurrentContext
        present(removeFavViewController, animated: true, completion: nil)
    }
    
    func shareAction(_ url: String?) {
        let activityVC = UIActivityViewController(activityItems: [url as AnyObject], applicationActivities: nil)
        activityVC.popoverPresentationController?.sourceView = self.view
        self.present(activityVC, animated: true, completion: nil)
    }
}

extension FavoriteBreweriesViewController: RemoveFavoriteDelegate {
    func confirmDeletion() {
        viewModel.deleteFavorite()
        
        self.presentedViewController?.dismiss(animated: true)
    }
    
    func cancelDeletion() {
        self.presentedViewController?.dismiss(animated: true)
    }
}
