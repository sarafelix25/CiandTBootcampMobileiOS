//
//  RemoveFavoriteViewController.swift
//  CI&T Brewery Finder
//
//  Created by Filipe Nunes on 13/06/22.
//

import Foundation
import UIKit

@objc protocol RemoveFavoriteDelegate {
    func confirmDeletion()
    func cancelDeletion()
}

class RemoveFavoriteViewController: UIViewController {

    @IBOutlet weak var backgroundView: UIView!
    
    override func viewDidLoad() {
        backgroundView.setShadowWithCornerRadius(cornerRadius: 30,
                                                 shadowColor: .gray,
                                                 shadowOffset: CGSize(width: 0, height: 1),
                                                 shadowOpacity: 0.4,
                                                 shadowRadius: 2)
    }

    weak var delegate: RemoveFavoriteDelegate?

    @IBAction func cancelButtonPressed(_ sender: Any) {
        delegate?.cancelDeletion()
    }
    
    @IBAction func confirmDeletionButtonPressed(_ sender: Any) {
        delegate?.confirmDeletion()
    }
}
