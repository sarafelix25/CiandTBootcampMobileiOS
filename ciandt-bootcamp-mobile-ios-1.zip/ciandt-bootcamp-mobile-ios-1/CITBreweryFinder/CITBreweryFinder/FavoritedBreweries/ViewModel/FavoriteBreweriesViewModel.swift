//
//  FavoriteBreweriesViewModel.swift
//  CI&T Brewery Finder
//
//  Created by Filipe Nunes on 08/06/22.
//

import Foundation
import CoreData

class FavoriteBreweriesViewModel{
    
    private let networkRepository: NetworkRepositoryProtocol
    private let databaseRepository: DataBaseRepositoryProtocol
    let state = Observable<FavoriteBreweriesViewState>(.start)
    var idToDelete: String? = nil
    
    init(networkRepository: NetworkRepositoryProtocol = NetworkRepository(),
         databaseRepository: DataBaseRepositoryProtocol = DataBaseRepository()) {
        self.databaseRepository = databaseRepository
        self.networkRepository = networkRepository
    }
    
    func getFavoriteBreweries() {
        self.state.value = .loading
        let breweries = databaseRepository.fetchFavorites()
        if breweries.count == 0 {
            self.state.value = .emptyFavorites
        }
        else {
            var searchResultsViewModels: [SearchResultsViewModel] = []
            
            for result in breweries {
                let brewery = Brewery(with: result)
                searchResultsViewModels.append(SearchResultsViewModel(with: brewery))
            }
            self.state.value = .success(breweryList: searchResultsViewModels)
        }
    }
    
    func deleteFavorite() {
        guard let id = idToDelete
        else {
            return
        }
        _ = databaseRepository.deleteFavorite(breweryId: id)
        idToDelete = nil
        self.state.value = .start
    }

}

enum FavoriteBreweriesViewState {
    case start
    case loading
    case success(breweryList: [SearchResultsViewModel])
    case emptyFavorites
}
