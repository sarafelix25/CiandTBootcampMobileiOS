//
//  RatingViewModel.swift
//  CI&T Brewery Finder
//
//  Created by Filipe Nunes on 04/06/22.
//

import Foundation

public protocol RatingViewModelDelegate: AnyObject {
    func didEvaluateBreweryWithSuccess()
}

public class RatingViewModel {
    
    private let networkRepository: NetworkRepositoryProtocol
    let state = Observable<RatingViewState>(.start)
    let breweryName: String
    let breweryID: String
    weak var delegate: RatingViewModelDelegate?

    let showEmailError = Observable<Bool>(false)
    
    let showGradeError = Observable<Bool>(false)
    
    init(name: String, id: String, networkRepository: NetworkRepositoryProtocol = NetworkRepository(), delegate: RatingViewModelDelegate? = nil){
        self.networkRepository = networkRepository
        self.breweryName = name
        self.breweryID = id
        self.delegate = delegate
    }
    
    func evaluateBrewery(email: String, breweryID: String, evaluation: String) {
        
        let isValidEmail = isValidEmail(email)
        showEmailError.value = isValidEmail
        
        let isValidGrade = isValidGrade(Double(evaluation) ?? 0.0)
        showGradeError.value = isValidGrade
        
        if isValidEmail && isValidGrade {
            networkRepository.breweryEvaluation(email: email, breweryID: breweryID, evaluation: evaluation) { result in
                switch result {
                case .alreadyEvaluated:
                    self.state.value = .alreadyEvaluated
                case .success:
                    self.state.value = .success
                    self.delegate?.didEvaluateBreweryWithSuccess()
                case .serverError:
                    self.state.value = .serverError
                case .none:
                    print("No Result")
                }
            }
        }
        
    }
    
    func isValidEmail(_ email: String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailPred = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailPred.evaluate(with: email)
    }
    
    func isValidGrade(_ average: Double) -> Bool{
        return average >= 1
    }
}

enum RatingViewState {
    case start
    case success
    case alreadyEvaluated
    case serverError
}
