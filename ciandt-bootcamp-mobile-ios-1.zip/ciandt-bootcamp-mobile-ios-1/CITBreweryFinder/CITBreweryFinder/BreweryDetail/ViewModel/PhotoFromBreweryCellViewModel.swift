//
//  PhotoFromBreweryCellViewModel.swift
//  CITBreweryFinder
//
//  Created by Filipe Nunes on 17/06/22.
//

import UIKit

class PhotoFromBreweryCellViewModel{
    
    let photo: Observable<String?>
    
    private let databaseRepository: DataBaseRepositoryProtocol
    
    init(with photo: String, databaseRepository: DataBaseRepositoryProtocol = DataBaseRepository()) {
        self.databaseRepository = databaseRepository
        self.photo = Observable(photo)
    }

    
}

