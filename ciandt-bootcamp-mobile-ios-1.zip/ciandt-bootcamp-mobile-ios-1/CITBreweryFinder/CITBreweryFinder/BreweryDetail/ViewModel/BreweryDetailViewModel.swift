//
//  BreweryDetailViewModel.swift
//  CI&T Brewery Finder
//
//  Created by Evele Kelle Lemos Silva on 24/05/22.
//

import Foundation


public class BreweryDetailViewModel {
    
    private let networkRepository: NetworkRepositoryProtocol
    private let databaseRepository: DataBaseRepositoryProtocol
    
    let state = Observable<BreweryDetailViewState>(.start)
    let breweryName = Observable<String>("")
    let id: String
    let website: String?
    let avgReviews = Observable<String>("")
    let starRating = Observable<Float>(0.0)
    let amountOfReviews = Observable<Int>(0)
    let type = Observable<String>("")
    
    let address = Observable<String>("")
    let coordinates = Observable<(Float,Float)>((0.0,0.0))
    let photos = Observable<[String]>([""])
    var idToDelete: String? = nil
    
    init(networkRepository: NetworkRepositoryProtocol = NetworkRepository(),
         databaseRepository: DataBaseRepositoryProtocol = DataBaseRepository(),
         breweryID: String, website: String){
        
        self.networkRepository = networkRepository
        self.databaseRepository = databaseRepository
        self.id = breweryID
        self.website = website
    }
    
    func getBreweryByID() {
        self.state.value = .loading
        networkRepository.fetchBreweryByID(id: id) { result, error in
            if let error = error {
                switch error {
                case .notFound:
                    self.state.value = .notFound
                }
            } else {
                self.state.value = .success
                self.breweryName.value = result.name
                self.avgReviews.value = result.average.description
                self.starRating.value = result.average
                self.amountOfReviews.value = result.sizeEvaluations
                self.type.value = result.breweryType
                self.address.value = result.street ?? ""
                self.coordinates.value = (result.latitude ?? 0.0, result.longitude ?? 0.0)
                self.photos.value = result.photos ?? []
            }
        }
    }
    
    func getRatingViewModel() -> RatingViewModel {
        return RatingViewModel(name: self.breweryName.value, id: self.id, delegate: self)
    }
    
    func getNumberOfReviews() -> String {
        return self.amountOfReviews.value == 1 ? NSLocalizedString("Details.numberOfEvaluationsOneResult", comment: "") : String(format: NSLocalizedString("Details.numberOfEvaluations", comment: ""), self.amountOfReviews.value)
    }
    
    func favorite(){
        let favoriteBrewery = FavoriteBreweryModel(breweryId: id,
                                                   breweryType: type.value,
                                                   average: starRating.value,
                                                   breweryName: breweryName.value)
        databaseRepository.saveFavorite(breweryFavorite: favoriteBrewery)
    }
    
    func isBreweryFavorite() -> Bool {
        return databaseRepository.isFavorite(breweryId: self.id)
    }
    
    func deleteFavorite() {
        guard let id = idToDelete
        else {
            return
        }
        _ = databaseRepository.deleteFavorite(breweryId: id)
        idToDelete = nil
        self.state.value = .start
    }
}
    extension BreweryDetailViewModel: RatingViewModelDelegate {
        public func didEvaluateBreweryWithSuccess() {
            state.value = .reload
        }
    }
    
    enum BreweryDetailViewState {
        case start
        case reload
        case loading
        case success
        case notFound
    }
