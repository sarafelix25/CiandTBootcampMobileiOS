//  BreweryDetailViewController.swift
//  CI&T Brewery Finder
//
//  Created by Filipe Nunes on 20/05/22.
//

import UIKit
import SwiftyStarRatingView
import Kingfisher

class BreweryDetailViewController: UIViewController {
    
    @IBOutlet weak var cardDetails: UIView!
    @IBOutlet weak var firstNameLetterBrewery: UILabel!
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var averageReviews: UILabel!
    @IBOutlet weak var amountOfReviews: UILabel!
    @IBOutlet weak var type: UILabel!
    @IBOutlet weak var website: UILabel!
    @IBOutlet weak var address: UILabel!
    @IBOutlet weak var loadingView: UIView!
    @IBOutlet weak var loadingActIndicator: UIActivityIndicatorView!
    @IBOutlet weak var photosCollection: UICollectionView!
    @IBOutlet weak var didAlreadyEvaluateView: UIView!
    @IBOutlet weak var loadingImageView: UIImageView!
    
    var loading1: UIImage!
    var loading2: UIImage!
    var loading3: UIImage!
    var loading4: UIImage!
    
    @IBOutlet weak var checkInMapButton: UIButton!
    var latitude: Float = 0.0
    var longitude: Float = 0.0
    var firstLetter: Substring = "C"
    var numberOfReviews: Int = 0
    var photos: [String] = []
    var showWebsite: Bool?
    
    @IBOutlet weak var starRating: SwiftyStarRatingView! {
        didSet {
            starRating.tintColor = UIColor(named: "dark-yellow")
            starRating.isEnabled = false
            starRating.tintAdjustmentMode = UIView.TintAdjustmentMode.normal
        }
    }
    
    var viewModel: BreweryDetailViewModel?
    var isFavorite: Bool = false
    var favoriteButton: UIBarButtonItem = UIBarButtonItem()
    var shareButton: UIBarButtonItem = UIBarButtonItem()
    weak var delegate: SearchResultCellDelegate?
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        setFavoriteIcon()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.delegate = self
        self.photosCollection.dataSource = self
        
        photosCollection.register(UINib(nibName: "PhotoFromBreweryCell", bundle: nil), forCellWithReuseIdentifier: "PhotoFromBreweryCell")
        didAlreadyEvaluateView.isHidden = true
        setupActivityIndicator()
        
        cardDetails.setShadowWithCornerRadius(cornerRadius: 30, shadowColor: .gray, shadowOffset: CGSize(width: 0, height: 1), shadowOpacity: 0.4, shadowRadius: 2)
        shareButton = UIBarButtonItem(image: UIImage(systemName: "square.and.arrow.up"), style: .plain, target: self, action: #selector(shareButtonTapped))
        favoriteButton = UIBarButtonItem(image: UIImage(systemName: "heart"), style: .plain, target: self, action: #selector(favoriteButtonTapped))
        
        setNavBarIcons()
        
        //        MARK: Bindingsx
        viewModel?.state.bind { [weak self] state in
            switch state {
            case .start:
                self?.showLoading(show: false)
                self?.setFavoriteIcon()
                self?.loadingView.isHidden = true
                self?.viewModel?.getBreweryByID()
            case .reload:
                self?.showLoading(show: false)
                self?.loadingView.isHidden = true
                self?.viewModel?.getBreweryByID()
                self?.didAlreadyEvaluateView.isHidden = false
                self?.starRating.tintColor = UIColor(named: "dark-yellow")
            case .success:
                self?.showLoading(show: false)
                self?.loadingView.isHidden = true
                self?.setupBrewery()
            case .loading:
                self?.showLoading(show: true)
            case .notFound:
                break
            }
        }
        
        print("WEBSITE BRWDTL: \(viewModel?.website)")
        self.website.text = viewModel?.website
        
        viewModel?.breweryName.bind { [weak self] name in
            self?.name.text = name
            
            let firstLetter = self?.name.text ?? "C"
            self?.firstNameLetterBrewery.text = String(firstLetter.first ?? "C")

        }
        
        viewModel?.avgReviews.bind { [weak self] avgReviews in
            self?.averageReviews.text = avgReviews
        }
        
        viewModel?.starRating.bind { [weak self] starRating in
            self?.starRating.value = CGFloat(starRating)
            self?.starRating.tintColor = UIColor(named: "dark-yellow")
            self?.starRating.isEnabled = false
        }
        
        viewModel?.amountOfReviews.bind { [weak self] reviews in
            self?.amountOfReviews.text = reviews.description
            self?.numberOfReviews = reviews
        }
        
        viewModel?.type.bind { [weak self] type in
            self?.type.text = type
        }
        
        viewModel?.address.bind { [weak self] address in
            self?.address.text = address
        }
  
        viewModel?.coordinates.bind { [weak self] coord in
            self?.latitude = coord.0
            self?.longitude = coord.1
        }
        
        viewModel?.photos.bind { [weak self] photos in
            self?.photos = photos
            self?.photosCollection.reloadData()
        }
    }
    
    func showLoading(show: Bool) {
        loadingView.isHidden = !show
        if show {
            loadingImageView.isHidden = false
        } else {
            loadingImageView.isHidden = true
        }
    }
    
    func setupActivityIndicator() {
        loading1 = UIImage(named: "breweryActInd1.png")
        loading2 = UIImage(named: "breweryActInd2.png")
        loading3 = UIImage(named: "breweryActInd3.png")
        loading4 = UIImage(named: "breweryActInd4.png")
        
        var images: [UIImage]!
        var animatedImage: UIImage!
        images = [loading1, loading2, loading3, loading4]
        animatedImage = UIImage.animatedImage(with: images, duration: 0.5)
        loadingImageView.image = animatedImage
    }
    
    
    func setupBrewery() {
        firstNameLetterBrewery.layer.masksToBounds = true
        firstNameLetterBrewery.layer.cornerRadius = firstNameLetterBrewery.frame.width/2

        DispatchQueue.main.async { [weak self] in
            self?.amountOfReviews.text = self?.viewModel?.getNumberOfReviews()
        }
    }
    
    func setFavoriteIcon() {
        isFavorite = viewModel?.isBreweryFavorite() ?? false

        if isFavorite {
            favoriteButton.image = UIImage(systemName: "heart.fill")
            favoriteButton.tintColor = UIColor(.red)
        } else {
            favoriteButton.image = UIImage(systemName: "heart")
            favoriteButton.tintColor = UIColor(.black)
        }
    }
    
    func setNavBarIcons() {
        if viewModel?.website != "" {
            navigationItem.rightBarButtonItems = [favoriteButton, shareButton]
        } else {
            navigationItem.rightBarButtonItems = [favoriteButton]
        }
    }
    
    //    MARK: Functions & Actions
    func showcaseGoogleMaps(latitude: Float?, longitude: Float?) {
        let url = String(Constants.googleMapsURL + "\(latitude ?? 0.0),\(longitude ?? 0.0)")
        
        if let newUrl = URL(string: url) {
            UIApplication.shared.open(newUrl, options: [:], completionHandler: { sucess in
                print("Open \(url): \(sucess)")
            })
        }
    }
    
    @IBAction func mapViewAction(_ sender: Any) {
        showcaseGoogleMaps(latitude: latitude, longitude: longitude)
    }
    
    @IBAction func clickEvaluateBrewery(_ sender: UIButton) {
        guard let ratingViewModel = viewModel?.getRatingViewModel() else { return }
        let ratingViewController = RatingViewController()
        
        ratingViewController.viewModel = ratingViewModel
        ratingViewController.modalPresentationStyle = .pageSheet
        if let sheet = ratingViewController.sheetPresentationController { sheet.detents = [.medium(), .large()] }
        
        present(ratingViewController, animated: true, completion: nil)
    }
    
    @objc func shareButtonTapped() {
        let activityVC = UIActivityViewController(activityItems: [viewModel?.website as AnyObject], applicationActivities: nil)
        activityVC.popoverPresentationController?.sourceView = self.view
        
        self.present(activityVC, animated: true, completion: nil)
    }
    
    @objc func favoriteButtonTapped() {
        if isFavorite {
            self.delegate?.deleteFavorite(id: viewModel?.id ?? "")
        } else {
            viewModel?.favorite()
        }
        setFavoriteIcon()
    }
}

extension BreweryDetailViewController: SearchResultCellDelegate {
    
    func deleteFavorite(id: String) {
        viewModel?.idToDelete = id
        let removeFavViewController = RemoveFavoriteViewController()
        removeFavViewController.delegate = self
        removeFavViewController.modalPresentationStyle = .overCurrentContext
        present(removeFavViewController, animated: true, completion: nil)
    }
    
    func shareAction(_ url: String?) {
        let activityVC = UIActivityViewController(activityItems: [url as AnyObject], applicationActivities: nil)
        activityVC.popoverPresentationController?.sourceView = self.view
        self.present(activityVC, animated: true, completion: nil)
    }
}

extension BreweryDetailViewController: RemoveFavoriteDelegate {
    func confirmDeletion() {
        viewModel?.deleteFavorite()
        self.presentedViewController?.dismiss(animated: true)
    }
    
    func cancelDeletion() {
        self.presentedViewController?.dismiss(animated: true)
    }
}

extension BreweryDetailViewController: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return photos.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "PhotoFromBreweryCell", for: indexPath) as! PhotoFromBreweryCell
        
        let url = URL(string: photos[indexPath.row])
        cell.breweryImageView.kf.setImage(with: url)

        return cell
    }
}

