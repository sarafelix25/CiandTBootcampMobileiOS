//
//  PhotoFromBreweryCell.swift
//  CITBreweryFinder
//
//  Created by Filipe Nunes on 17/06/22.
//

import UIKit
import Kingfisher

class PhotoFromBreweryCell: UICollectionViewCell {
    
    @IBOutlet weak var breweryImageView: UIImageView!
    
    var viewModel: SearchResultsViewModel?
    
    func setup(_ viewModel: SearchResultsViewModel) {
            
        self.viewModel = viewModel
        
        viewModel.photos.bind { [weak self] photos in
            let url = URL(string: photos?.first ?? "")
            self?.breweryImageView.kf.setImage(with: url)
        }
        
        self.setShadowWithCornerRadius(cornerRadius: 16, shadowColor: .gray, shadowRadius: 0)
    }
    
    
}

