//
//  RatingViewController.swift
//  CI&T Brewery Finder
//
//  Created by Evele Kelle Lemos Silva on 18/05/22.
//

import Foundation
import UIKit
import SwiftyStarRatingView


class RatingViewController: UIViewController {

    var viewModel = RatingViewModel(name: "", id: "")
    
    
    // MARK: - Initialization
    @available(*, unavailable)
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    init(){
        super.init(nibName: nil, bundle: nil)
    }
    
    @IBOutlet weak var breweryName: UILabel! {
        didSet {
            breweryName.text = "Avalie \(viewModel.breweryName)"
        }
    }
    
    @IBOutlet weak var email: UITextField!
    
    @IBOutlet weak var emailError: UILabel! {
        didSet {
            emailError.isHidden = true
        }
    }
    
    @IBOutlet weak var gradeError: UILabel! {
        didSet {
            gradeError.isHidden = true
        }
    }
    
    @IBOutlet weak var ratingContainer: SwiftyStarRatingView! {
        didSet {
            ratingContainer.tintColor = UIColor(named: "dark-yellow")
            ratingContainer.allowsHalfStars = false
        }
    }
    
    @IBOutlet weak var saveButton: UIButton! {
        didSet {
            saveButton.backgroundColor = UIColor(named: "light-yellow")
            saveButton.layer.cornerRadius = 20
        }
    }
    @IBOutlet weak var assessmentView: UIView! {
        didSet {
            assessmentView.isHidden = true
        }
    }
    
    @IBOutlet weak var successView: UIView! {
        didSet {
            successView.isHidden = true
        }
    }
    
    @IBOutlet weak var errorView: UIView! {
        didSet {
            errorView.isHidden = true
        }
    }
    
    
    override func viewDidLoad() {
        viewModel.state.bind { [weak self] state in
            switch state {
            case .start:
                self?.setupAssessmentUI()
            case .success:
                self?.setupSuccessUI()
            case .serverError:
                break
            case .alreadyEvaluated:
                self?.setupAlreadyEvaluatedUI()
            }
        }
        
        viewModel.showEmailError.bindWithoutFire { [weak self] showEmail in
            self?.emailError.isHidden = showEmail
        }
        
        viewModel.showGradeError.bindWithoutFire { [weak self] showGrade in
            self?.gradeError.isHidden = showGrade
        }
    }
    
    @IBAction func clickSaveButton(_ sender: UIButton) {
        viewModel.evaluateBrewery(email: email.text ?? "",
                                  breweryID: viewModel.breweryID,
                                  evaluation: ratingContainer.value.description)
    }
    
    @IBAction func emailClick(_ sender: UITextField) {
        email.textColor = UIColor.black
        saveButton.tintColor = UIColor.black
        saveButton.backgroundColor = UIColor(named: "dark-yellow")
    }
    
    @IBAction func clickCloseButton(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
    
    func setupSuccessUI() {
        successView.isHidden = false
        errorView.isHidden = true
        assessmentView.isHidden = true
    }
    
    func setupAlreadyEvaluatedUI() {
        successView.isHidden = true
        errorView.isHidden = false
        assessmentView.isHidden = true
    }
    
    func setupAssessmentUI() {
        successView.isHidden = true
        errorView.isHidden = true
        assessmentView.isHidden = false
    }
    
}
