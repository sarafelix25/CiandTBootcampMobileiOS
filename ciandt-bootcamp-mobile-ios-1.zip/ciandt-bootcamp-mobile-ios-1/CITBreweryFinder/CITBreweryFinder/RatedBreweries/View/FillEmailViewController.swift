//
//  RatedBreweriesViewController.swift
//  CI&T Brewery Finder
//
//  Created by Evele Kelle Lemos Silva on 09/06/22.
//

import Foundation
import UIKit

class FillEmailViewController: UIViewController {
    
    let viewModel = FillEmailViewModel()
    
    @IBOutlet weak var email: UITextField!
    @IBOutlet weak var emailError: UILabel! {
        didSet {
            emailError.isHidden = true
        }
    }
    @IBOutlet weak var confirmButton: UIButton! {
        didSet {
            confirmButton.layer.cornerRadius = 20
        }
    }
    
    @IBAction func emailClick(_ sender: Any) {
        confirmButton.backgroundColor = UIColor(named: "dark-yellow")

    }
    
    @IBAction func clickConfirmButton(_ sender: Any) {
        let isValid = viewModel.isValidEmail(email.text ?? "")
        emailError.isHidden = isValid
        
        if isValid {
            let ratedBreweriesViewController = RatedBreweriesViewController()
            let ratedBreweriesViewModel = RatedBreweriesViewModel(email: email.text ?? "")
            
            ratedBreweriesViewController.viewModel = ratedBreweriesViewModel
            self.navigationController?.pushViewController(ratedBreweriesViewController, animated: true)
            
            emailError.layer.borderColor = UIColor.red.cgColor
        }
        
    }
    
    override func viewDidLoad() {
        
    }
    
}
