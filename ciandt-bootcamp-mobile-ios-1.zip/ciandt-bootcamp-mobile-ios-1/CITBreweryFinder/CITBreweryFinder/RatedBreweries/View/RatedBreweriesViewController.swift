//
//  RatedBreweriesViewController.swift
//  CI&T Brewery Finder
//
//  Created by Evele Kelle Lemos Silva on 12/06/22.
//

import Foundation
import UIKit

class RatedBreweriesViewController: UIViewController {
    
    @IBOutlet weak var loadingView: UIView!
    @IBOutlet weak var loadingActIndicator: UIActivityIndicatorView!
    @IBOutlet weak var loadingImageView: UIImageView!
    
    var loading1: UIImage!
    var loading2: UIImage!
    var loading3: UIImage!
    var loading4: UIImage!
    
    @IBOutlet weak var tableView: UITableView! {
        didSet {
            tableView.isHidden = true
        }
    }
    @IBOutlet weak var numberOfResults: UILabel! {
        didSet {
            numberOfResults.isHidden = true
        }
    }
    @IBOutlet weak var noResultsView: UIView! {
        didSet {
            noResultsView.isHidden = true
        }
    }
    
    var breweryList: [RatedBreweryCellViewModel] = []
    var viewModel: RatedBreweriesViewModel?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initialSetup()
        setupActivityIndicator()
        
        viewModel?.state.bind { [weak self] state in
            switch state {
            case .start:
                self?.loadingImageView.isHidden = true
                self?.showLoading(show: false)
                self?.getBreweriesByEmail()
            case .empty:
                self?.loadingImageView.isHidden = true
                self?.showLoading(show: false)
                self?.showEmptyUI()
            case .success(let breweryList):
                self?.loadingImageView.isHidden = true
                self?.showLoading(show: false)
                self?.breweryList = breweryList
                self?.showTableView()
                self?.tableView.reloadData()
            case .loading:
                self?.showLoading(show: true)
            case .error:
                break
            }
        }
    }
    
    func initialSetup() {
        tableView.dataSource = self
        tableView.delegate = self
        tableView.register(UINib(nibName: "RatedBreweryCell", bundle: nil), forCellReuseIdentifier: "RatedBreweryCell")
    }
    
    func setupActivityIndicator() {
        loading1 = UIImage(named: "breweryActInd1.png")
        loading2 = UIImage(named: "breweryActInd2.png")
        loading3 = UIImage(named: "breweryActInd3.png")
        loading4 = UIImage(named: "breweryActInd4.png")
        
        var images: [UIImage]!
        var animatedImage: UIImage!
        images = [loading1, loading2, loading3, loading4]
        animatedImage = UIImage.animatedImage(with: images, duration: 0.5)
        loadingImageView.image = animatedImage
    }
    
    func showLoading(show: Bool) {
        if show {
            loadingImageView.isHidden = false
        } else {
            loadingImageView.isHidden = true
        }
    }
    
    func getBreweriesByEmail() {
        viewModel?.getRatedByEmail()
    }
    
    func showTableView() {
        tableView.isHidden = false
        noResultsView.isHidden = true
        numberOfResults.isHidden = false
        numberOfResults.text = breweryList.count == 1 ? NSLocalizedString("Favorite.numberOfBrewerySearchOneResult", comment: "") :
                        String(format: NSLocalizedString("Favorite.numberOfBrewerySearchResults", comment: ""), breweryList.count)
    }
    
    func showEmptyUI() {
        tableView.isHidden = true
        noResultsView.isHidden = false
        numberOfResults.isHidden = true
        
        let view = UINib(nibName: "NoRatingBrewery", bundle: .main).instantiate(withOwner: nil, options: nil).first as! UIView
        view.frame = self.noResultsView.bounds
        noResultsView.addSubview(view)
    }
}

extension RatedBreweriesViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return breweryList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "RatedBreweryCell", for: indexPath) as? RatedBreweryCell else {
            return UITableViewCell()
        }
        cell.selectionStyle = .none
        cell.setupWith(breweryList[indexPath.row])
        return cell
    }
}

extension RatedBreweriesViewController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let breweryDetailViewController = BreweryDetailViewController()
        let breweryDetailViewModel = BreweryDetailViewModel(breweryID: breweryList[indexPath.row].id.value, website: "")
        
        breweryDetailViewController.viewModel = breweryDetailViewModel
        self.navigationController?.pushViewController(breweryDetailViewController, animated: true)
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 15
    }

}
