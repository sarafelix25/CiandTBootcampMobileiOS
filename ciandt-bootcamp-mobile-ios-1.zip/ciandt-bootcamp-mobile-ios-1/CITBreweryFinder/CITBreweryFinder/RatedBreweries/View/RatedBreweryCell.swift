//
//  RatedBreweryCell.swift
//  CI&T Brewery Finder
//
//  Created by Evele Kelle Lemos Silva on 10/06/22.
//

import Foundation
import UIKit
import SwiftyStarRatingView

class RatedBreweryCell:  UITableViewCell {
    
    @IBOutlet weak var cellBackground: UIView!
    @IBOutlet weak var firstLetter: UILabel!
    @IBOutlet weak var breweryName: UILabel!
    @IBOutlet weak var grade: UILabel!
    @IBOutlet weak var rateView: SwiftyStarRatingView! {
        didSet {
            rateView?.isEnabled = false
        }
    }
    
    var viewModel: RatedBreweryCellViewModel?
    
    func setupWith (_ viewModel: RatedBreweryCellViewModel) {
        cellBackground?.setShadowWithCornerRadius(cornerRadius: 30, shadowColor: .gray, shadowOffset: CGSize(width: 0, height: 1), shadowOpacity: 0.4, shadowRadius: 2)
        self.viewModel = viewModel
        
        viewModel.name.bind { [weak self] name in
            self?.breweryName?.text = name
        }
        
        viewModel.firstLetter.bind { [weak self] firstLetter in
            self?.firstLetter?.text = firstLetter
        }
        
        viewModel.grade.bind { [weak self] grade in
            self?.grade?.text = String(grade)
            self?.rateView?.value = CGFloat(grade)
        }
        
    }
    
}
