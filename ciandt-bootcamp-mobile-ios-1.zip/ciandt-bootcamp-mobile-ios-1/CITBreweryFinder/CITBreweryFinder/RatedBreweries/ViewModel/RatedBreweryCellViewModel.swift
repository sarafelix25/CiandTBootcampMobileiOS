//
//  RatedBreweryCellViewModel.swift
//  CI&T Brewery Finder
//
//  Created by Evele Kelle Lemos Silva on 13/06/22.
//

import Foundation

class RatedBreweryCellViewModel {
    let id: Observable<String>
    let name: Observable<String>
    let grade: Observable<Float>
    let firstLetter: Observable<String>
    
    init(with brewery: Brewery) {
        self.id = Observable(brewery.id)
        self.name = Observable(brewery.name)
        self.grade = Observable(brewery.average)
        self.firstLetter = Observable(String(brewery.name.first ?? " "))
    }
    
}
