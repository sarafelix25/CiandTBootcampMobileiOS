//
//  RatedBreweriesViewModel.swift
//  CI&T Brewery Finder
//
//  Created by Sara Batista dos Santos Felix on 13/06/22.
//

import UIKit

class RatedBreweriesViewModel {
    
    private let networkRepository: NetworkRepositoryProtocol
    let state = Observable<RatedBreweriesViewState>(.start)
    var brewery: Observable<Brewery?>
    let email: String
    
    init(networkRepository: NetworkRepositoryProtocol = NetworkRepository(), email: String) {
        self.networkRepository = networkRepository
        self.brewery = Observable(nil)
        self.email = email
    }
    
    func getRatedByEmail() {
        self.state.value = .loading
        networkRepository.fetchBreweryRatedByEmail(email: email) { result, error in
            if let error = error {
                switch error {
                case .error:
                    self.state.value = .error
                }
            } else {
                if result.count == 0 {
                    self.state.value = .empty
                } else {
                    var cellViewModel = [RatedBreweryCellViewModel]()
                    for cell in result {
                        cellViewModel.append(RatedBreweryCellViewModel(with: cell))
                    }
                    self.state.value = .success(breweryList: cellViewModel)
                }
            }
        }
    }
}

enum RatedBreweriesViewState {
    case start
    case loading
    case success(breweryList: [RatedBreweryCellViewModel])
    case empty
    case error
}
