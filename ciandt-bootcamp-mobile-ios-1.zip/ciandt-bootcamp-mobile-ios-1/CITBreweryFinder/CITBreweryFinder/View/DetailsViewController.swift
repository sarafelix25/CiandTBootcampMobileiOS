//
//  DetailsViewController.swift
//  CI&T Brewery Finder
//
//  Created by André Levi Oliveira Silva on 19/05/22.
//

import Foundation
