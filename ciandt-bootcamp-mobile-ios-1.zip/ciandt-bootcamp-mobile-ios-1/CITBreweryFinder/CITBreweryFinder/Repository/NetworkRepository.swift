//
//  BreweryRepository.swift
//  CI&T Brewery Finder
//
//  Created by Evele Kelle Lemos Silva on 16/05/22.
//

import Foundation
import Alamofire

public protocol NetworkRepositoryProtocol {
    func fetchBreweryByLocal(_ local: String, completion: @escaping ([Brewery], BreweryError?) -> ())
    
    func fetchBreweryByID(id: String, completion: @escaping (Brewery, BreweryDetailError?) -> ())
    
    func breweryEvaluation(email: String, breweryID: String, evaluation: String, completion: @escaping(BreweryPostResult?) -> ())
    
    func fetchBreweryTopTen(completion: @escaping ([Brewery], BreweryError?) -> ())
    
    func fetchBreweryRatedByEmail(email: String, completion: @escaping ([Brewery], BreweryRatedError?) -> ())
}


class NetworkRepository: NetworkRepositoryProtocol {
    
    func fetchBreweryByLocal(_ local: String, completion: @escaping ([Brewery], BreweryError?) -> ()){
        Alamofire.request(Constants.breweryBaseURL, method: .get, parameters: ["by_city": local])
        .responseJSON { (response) in
            if response.result.isSuccess {
                guard let data = response.data else {
                    completion([], .noEntry)
                    return
                }
                do {
                    let result = try JSONDecoder().decode([Brewery].self, from: data)
                    print(result)
                    completion(result, nil)
                } catch {
                    print(error)
                    completion([], .notFound)
                }
            }
        }
    }
    
    func fetchBreweryRatedByEmail(email: String, completion: @escaping ([Brewery], BreweryRatedError?) -> ()) {
        let myRatings = Constants.breweryRatedByEmail + "\(email)"
        Alamofire.request(myRatings, method: .get, parameters: nil)
        .responseJSON { (response) in
            if response.result.isSuccess {
                guard let data = response.data else {
                    return
                }
                do {
                    let result = try JSONDecoder().decode([Brewery].self, from: data)
                    completion(result, nil)
                } catch {
                    completion([], .error)
                }
            }
        }
    }
    
    func fetchBreweryTopTen(completion: @escaping ([Brewery], BreweryError?) -> ()){
            Alamofire.request(Constants.breweryTopTen, method: .get, parameters: nil)
                .responseJSON { (response) in
                    guard let data = response.data else {
                        completion([], .noEntry)
                        return
                    }
                    
                    do {
                        let result = try JSONDecoder().decode([Brewery].self, from: data)
                        print(result)
                        completion(result, nil)
                    } catch {
                        print(error)
                        completion([], .notFound)
                        
                    }
                }
        }
    
    
    func fetchBreweryByID(id: String, completion: @escaping (Brewery, BreweryDetailError?) -> ()) {
        let API_URL = Constants.breweryBaseURL + "/\(id)"
        let emptyBrewery = Brewery(id: "", name: "", breweryType: "", city: "", state: "", postalCode: "", country: "", average: 0.0, sizeEvaluations: 0)
        
        Alamofire.request(API_URL, method: .get, parameters: nil, encoding: JSONEncoding.default)
            .responseJSON { response in
                guard let data = response.data else {
                    return
                }
                
                do {
                    let result = try JSONDecoder().decode(Brewery.self, from: data)
                    completion(result, nil)
                } catch {
                    completion(emptyBrewery, .notFound)
                }
            }
    }
    
    func breweryEvaluation(email: String, breweryID: String, evaluation: String, completion: @escaping(BreweryPostResult?) -> ()) {
        let params: Parameters = [
            "email": email,
            "brewery_id": breweryID,
            "evaluation_grade": evaluation
        ]
        
        Alamofire.request(Constants.postRatingURL,
                          method: .post,
                          parameters: params,
                          encoding: JSONEncoding.default,
                          headers: nil)
        .validate(statusCode: Constants.startSuccessServerReturn ..< Constants.endSuccessServerReturn).responseJSON { AFdata in
            do {
                
                if let statusCode = AFdata.response?.statusCode {
                    if statusCode >= Constants.startClientErrorReturn && statusCode <= Constants.endClientErrorReturn { return completion(.alreadyEvaluated) }
                    else if statusCode >= Constants.startServerErrorReturn && statusCode <= Constants.endServerErrorReturn { return completion(.serverError) }
                }
                
                if let dataReturn = AFdata.data {
                    guard let jsonObject = try JSONSerialization.jsonObject(with: dataReturn) as? [String: Any] else {
                        return completion(.serverError)
                    }
                
                    guard let prettyJsonData = try? JSONSerialization.data(withJSONObject: jsonObject, options: .prettyPrinted) else {
                        return completion(.serverError)
                    }
                    guard let prettyPrintedJson = String(data: prettyJsonData, encoding: .utf8) else {
                        return completion(.serverError)
                    }
                    
                    print(prettyPrintedJson)
                    completion(.success)
                }
            } catch {
                print("Error: Trying to convert JSON data to string")
                return completion(.serverError)
            }
        }
    }
}
