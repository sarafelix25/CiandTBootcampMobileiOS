//
//  Constants.swift
//  CI&T Brewery Finder
//
//  Created by Evele Kelle Lemos Silva on 16/05/22.
//

import Foundation

class Constants {
    
    static let baseURL = "https://bootcamp-mobile-01.eastus.cloudapp.azure.com"
    
    static let breweryBaseURL = "\(baseURL)/breweries"
    
    static let breweryTopTen = "\(baseURL)/breweries/topTen"
    
    static let googleMapsURL = "https://maps.google.com/maps?q="
    
    static let postRatingURL = "https://bootcamp-mobile-01.eastus.cloudapp.azure.com/breweries"
    
    static let breweryRatedByEmail = "\(breweryBaseURL)/myEvaluations/"
    
    static let startSuccessServerReturn = 200
    
    static let endSuccessServerReturn = 299
    
    static let startClientErrorReturn = 400
    
    static let endClientErrorReturn = 499
    
    static let startServerErrorReturn = 500
    
    static let endServerErrorReturn = 599
    
}
