//
//  DataBaseRepository.swift
//  CI&T Brewery Finder
//
//  Created by Evele Kelle Lemos Silva on 09/06/22.
//

import Foundation
import CoreData
import UIKit

public protocol DataBaseRepositoryProtocol {
    func saveFavorite(breweryFavorite: FavoriteBreweryModel)
    func fetchFavorites() -> [Favorite]
    func isFavorite(breweryId: String) -> Bool
    func deleteFavorite(breweryId: String) -> Bool 
}

class DataBaseRepository: DataBaseRepositoryProtocol {
    
    func saveFavorite(breweryFavorite: FavoriteBreweryModel) {
        
        if isFavorite(breweryId: breweryFavorite.breweryId) {
            return
        }
        else {
            guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
                return
            }
            
            let managedContext = appDelegate.persistentContainer.viewContext
            
            let entity = NSEntityDescription.entity(forEntityName: "Favorite",
                                                    in: managedContext)!
            
            let brewery = NSManagedObject(entity: entity,
                                          insertInto: managedContext)
            
            brewery.setValue(breweryFavorite.breweryId, forKeyPath: "breweryId")
            brewery.setValue(breweryFavorite.breweryType, forKeyPath: "breweryType")
            brewery.setValue(breweryFavorite.average, forKeyPath: "average")
            brewery.setValue(breweryFavorite.breweryName, forKeyPath: "breweryName")
            
            do {
                try managedContext.save()
            } catch let error as NSError {
                print("Could not save. \(error), \(error.userInfo)")
            }
        }
    }
    
    func fetchFavorites() -> [Favorite] {
        var breweries: [Favorite] = []
        
        let appDelegate = UIApplication.shared.delegate as? AppDelegate
        
        let managedContext = appDelegate!.persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Favorite")
        
        do {
            breweries = try managedContext.fetch(fetchRequest) as! [Favorite]
        } catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
        
        return breweries
    }
    
    func isFavorite(breweryId: String) -> Bool {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
            return false
        }
        
        let managedContext = appDelegate.persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Favorite")
        
        fetchRequest.predicate = NSPredicate(format: "breweryId==%@", breweryId)
        do {
            let breweries = try managedContext.fetch(fetchRequest)
            return breweries.count > 0
        }
        
        catch {
            return false
        }
    }
    
    func deleteFavorite(breweryId: String) -> Bool {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
            return false
        }
        
        let managedContext = appDelegate.persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Favorite")
        
        fetchRequest.predicate = NSPredicate(format: "breweryId==%@", breweryId)
        do {
            let breweries = try managedContext.fetch(fetchRequest)
            for brewery in breweries {
                managedContext.delete(brewery)
            }
            try managedContext.save()
            return true
        }
        
        catch {
            return false
        }
    }
    
}
